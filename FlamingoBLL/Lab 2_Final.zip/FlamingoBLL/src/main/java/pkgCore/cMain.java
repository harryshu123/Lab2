package pkgCore;

import pkgCore.Hand;

public class cMain {

	public static void main(String[] args) throws Exception {
		
		Hand playerHand = new Hand();
		playerHand.ScoreHand();

	}

}
